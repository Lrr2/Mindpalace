TTYPEHASH = {
:CHILDOFLIGHT => {
	:ID => 0,
	:title => "Child of Light",
	:skill => 0,
},

:TRAINER_AEVIS => {
	:ID => 1,
	:title => "Pokémon Trainer",
	:skill => 150,
	:moneymult => 15,
	:battleBGM => "Battle - Rival.mp3",
	:player => true
},

:TRAINER_AEVIA => {
	:ID => 2,
	:title => "Pokémon Trainer",
	:skill => 150,
	:moneymult => 15,
	:battleBGM => "Battle - Rival.mp3",
	:player => true
},

:TRAINER_ARIA => {
	:ID => 3,
	:title => "Pokémon Trainer",
	:skill => 150,
	:moneymult => 15,
	:battleBGM => "Battle - Rival.mp3",
	:player => true
},

:TRAINER_AXEL => {
	:ID => 4,
	:title => "Pokémon Trainer",
	:skill => 150,
	:moneymult => 14,
	:battleBGM => "Battle - Rival.mp3",
	:player => true
},

:TRAINER_ALAIN => {
	:ID => 5,
	:title => "Pokémon Trainer",
	:skill => 150,
	:moneymult => 0,
	:battleBGM => "Battle - Rival.mp3",
	:player => true
},

:TRAINER_AERO => {
	:ID => 6,
	:title => "Pokémon Trainer",
	:skill => 150,
	:moneymult => 15,
	:battleBGM => "Battle - Rival.mp4",
	:moneymult => 0,
	:player => true
},

:TRAINER_ANA => {
	:ID => 7,
	:title => "Pokémon Trainer",
	:skill => 100,
	:battleBGM => "Battle - Rival.mp4",
	:moneymult => 0,
	:player => true
},

:LOSTHEIR => {
	:ID => 8,
	:title => "Lost Heir",
	:skill => 105,
	:moneymult => 0,
	:battleBGM => "Battle - Bringer of Chaos.mp3",
},

:RESEARCHER => {
	:ID => 9,
	:title => "Researcher",
	:skill => 105,
	:moneymult => 0,
	:battleBGM => "Battle - Researcher.mp3",
},

:NINJA => {
	:ID => 309,
	:title => "Ninja",
	:skill => 105,
	:moneymult => 0,
}}