class PokeBattle_Battler
  # Streamlining of Minior
  def pbShieldsUp?
    return false if @species != :MINIOR
    return false if (@ability != :SHIELDSDOWN) || @effects[:Transform]
    return false if self.form != 7
    return true
  end
  # End of Minior streamlining

  def pbCanStatus?(showMessages,ignorestatus=false) #catchall true/false for situations where one can't be statused
    if @ability== :PURIFYINGSALT && !(self.moldbroken)
      @battle.pbDisplay(_INTL("{1}'s Purifying Salt protects it from status!", pbThis)) if showMessages
      return false
    end
    if ((@ability== :FLOWERVEIL || pbPartner.ability== :FLOWERVEIL) && (hasType?(:GRASS) || @battle.FE == :BEWITCHED)) && !(self.moldbroken)
      @battle.pbDisplay(_INTL("{1} is protected by Flower Veil!",pbThis)) if showMessages
      return false
    end
    if (@battle.FE == :MISTY || @battle.state.effects[:MISTY] > 0) && !isAirborne? # Misty Field
      @battle.pbDisplay(_INTL("Misty Terrain prevents {1} from being inflicted by status!",pbThis(true))) if showMessages
      return false
    end
    if Rejuv && @battle.FE == :DRAGONSDEN && hasWorkingItem(:AMULETCOIN) # Dragon's Den
      @battle.pbDisplay(_INTL("Amulet Coin prevents {1} from being inflicted by status on Dragon's Den!",pbThis)) if showMessages
      return false
    end
    if (!ignorestatus && !self.status.nil?) || (self.ability== :COMATOSE && @battle.FE!=:ELECTERRAIN)
      @battle.pbDisplay(_INTL("{1} is already statused!",pbThis)) if showMessages
      return false
    end
    if (@damagestate.substitute || @effects[:Substitute]>0) && (!@battle.lastMoveUsed.is_a?(Symbol) || !$cache.moves[@battle.lastMoveUsed].checkFlag?(:soundmove))
      @battle.pbDisplay(_INTL("{1} is hidding behind a Substitute!",pbThis)) if showMessages
      return false
    end
    if pbShieldsUp?
      @battle.pbDisplay(_INTL("{1} shielded itself from status!",pbThis)) if showMessages
      return false
    end
    if pbOwnSide.effects[:Safeguard]>0 && (@battle.battlers[@battle.lastMoveUser]).ability != (:INFILTRATOR)    
      @battle.pbDisplay(_INTL("{1}'s team is protected by Safeguard!",pbThis)) if showMessages
      return false
    end
    return true
  end

#===============================================================================
# Sleep 
#===============================================================================
  def pbCanSleep?(showMessages,selfsleep=false,ignorestatus=false)
    return false if isFainted? && !(Rejuv && isbossmon && @shieldCount>0)
    if (!ignorestatus && status== :SLEEP) || (self.ability== :COMATOSE && @battle.FE != :ELECTERRAIN)
      @battle.pbDisplay(_INTL("{1} is already asleep!",pbThis)) if showMessages
      return false
    end
    return false if !pbCanStatus?(showMessages,ignorestatus)
    if !(self.ability== :SOUNDPROOF)
      for i in 0...4
        if @battle.battlers[i].effects[:Uproar]>0
          @battle.pbDisplay(_INTL("But the uproar kept {1} awake!",pbThis(true))) if showMessages
          return false
        end
      end
    end
    if ((self.ability== :VITALSPIRIT) || (self.ability== :INSOMNIA) || (self.ability== :SWEETVEIL))  && !(self.moldbroken)
         abilityname=getAbilityName(self.ability)
         @battle.pbDisplay(_INTL("{1} stayed awake using its {2}!",pbThis,abilityname)) if showMessages
         return false
    end
    if (pbPartner.ability== :SWEETVEIL) && !(self.moldbroken)
      abilityname=getAbilityName(pbPartner.ability)
      @battle.pbDisplay(_INTL("{1} stayed awake using its partner's {2}!",pbThis,abilityname)) if showMessages
      return false
    end
    if self.ability== :WORLDOFNIGHTMARES
      @battle.pbDisplay(_INTL("{1}'s dreams jolted them right back up!",pbThis)) if showMessages
      return false
    end
    if (@battle.FE == :ELECTERRAIN || @battle.state.effects[:ELECTERRAIN] > 0) && !isAirborne? # lawds electric overlay prevents sleep
      @battle.pbDisplay(_INTL("The electricity jolted {1} awake!",pbThis)) if showMessages
      return false
    end
    if @battle.ProgressiveFieldCheck(PBFields::CONCERT,3,4)
      @battle.pbDisplay(_INTL("The concert is too loud and hype to sleep!",pbThis)) if showMessages
      return false
    end
    if self.ability== :EARLYBIRD && !(self.moldbroken) && @battle.FE == :SKY
      @battle.pbDisplay(_INTL("{1} can't fall asleep in the open skies!",pbThis)) if showMessages
      return false
    end
    return true
  end

  def pbCanSleepYawn?
    return false if !pbCanStatus?(true)
    if !(@ability== :SOUNDPROOF)
      for i in 0...4
        return false if @battle.battlers[i].effects[:Uproar]>0
      end
    end
    if ((@ability== :VITALSPIRIT) || (@ability== :INSOMNIA)) &&  !(self.moldbroken) || pbShieldsUp?
      return false
    end
    if (pbPartner.ability== :SWEETVEIL || @ability== :SWEETVEIL) && !(self.moldbroken)
       @battle.pbDisplay(_INTL("{1} is protected by Sweet Veil!",pbThis)) #if showMessages
      return false
    end
    if @ability== :WORLDOFNIGHTMARES
      @battle.pbDisplay(_INTL("{1}'s dreams jolted them right back up!",pbThis))
      return false
    end
    if @battle.FE == :ELECTERRAIN && !isAirborne?
      @battle.pbDisplay(_INTL("The electricity jolted {1} awake!",pbThis)) #if showMessages
      return false
    end
    if @battle.ProgressiveFieldCheck(PBFields::CONCERT,3,4)
      @battle.pbDisplay(_INTL("The concert is too loud and hype to sleep!",pbThis)) #if showMessages
      return false
    end
    return true
  end

  def pbSleep 
    self.status=:SLEEP
    # LAWDS mod - global nerf to sleep, sleep is guaranteed to last 2 turns, then 1 turn, alternating.
    sleepincrement = self.pbOwnSide.effects[:SleepPenalty] ? 0 : 1
    sleepcount = 2 + sleepincrement
    self.statusCount = sleepcount
    self.pbOwnSide.effects[:SleepPenalty] = !(self.pbOwnSide.effects[:SleepPenalty])
    pbCancelMoves
    @battle.pbCommonAnimation("Sleep",self,nil)
  end

  def pbNightTerror # LAWDS - checks all mons on the field for Night Terror and activates it. Not called within pbSleep because it leads to clumsy presentation
    return if @battle.FE == :RAINBOW
    sleeplowered = false
        for i in @battle.battlers
          next if i.isFainted?
          next if i == self
          if i.ability== :NIGHTTERROR && !i.pbTooHigh?(PBStats::SPEED,nil,:NIGHTTERROR)
            sleeplowered = true
            @battle.pbCommonAnimation("StatUp", i, nil)
            i.pbIncreaseStatBasic(PBStats::SPEED,1,false,nil,false,:NIGHTTERROR)
            @battle.pbDisplay(_INTL("{1}'s Night Terror boosted its Speed!", i.pbThis))
          end
        end
  end

  def pbSleepSelf(duration=-1)
    self.status=:SLEEP
    if duration>0
      self.statusCount=duration
    else
      self.statusCount=2+@battle.pbRandom(3)
    end
    self.shedskin=0 # lawds shed skin turn tracker
    pbCancelMoves
    @battle.pbCommonAnimation("Sleep",self,nil)
  end

#===============================================================================
# Poison
#===============================================================================
  def pbCanPoison?(showMessages, ownToxicOrb=false, corrosion=false)
    return false if isFainted? && !(Rejuv && isbossmon && @shieldCount>0)
    if status== :POISON
      @battle.pbDisplay(_INTL("{1} is already poisoned.",pbThis)) if showMessages
      return false
    end
    return false if !pbCanStatus?(showMessages)                       # LAWDS - dhelmise crest acts like steel type
    if (hasType?(:POISON) || (hasType?(:STEEL) && !hasWorkingItem(:RINGTARGET)) || self.crested == :DHELMISE) && !(self.corroded || corrosion)
      @battle.pbDisplay(_INTL("It doesn't affect {1}...",pbThis(true))) if showMessages
      return false
    end
    if ((self.ability== :IMMUNITY) || (self.ability== :PASTELVEIL && @battle.FE != :INFERNAL))  && !(self.moldbroken)
        @battle.pbDisplay(_INTL("{1}'s {2} prevents poisoning!",pbThis,getAbilityName(self.ability))) if showMessages
        return false
    end
    if (pbPartner.ability== :PASTELVEIL && @battle.FE != :INFERNAL) && !(self.moldbroken)
      abilityname=getAbilityName(pbPartner.ability)
      @battle.pbDisplay(_INTL("{1} stayed healthy using its partner's {2}!",pbThis,abilityname)) if showMessages
      return false
    end
    return true
  end

  def pbCanPoisonSynchronize?(opponent,showMessages=false)
    return false if isFainted? && !(Rejuv && isbossmon && @shieldCount>0)
    return false if !pbCanStatus?(showMessages)                           # LAWDS - dhelmise crest acts like steel type
    if hasType?(:POISON) || (hasType?(:STEEL) && !hasWorkingItem(:RINGTARGET) || self.crested == :DHELMISE)
      @battle.pbDisplay(_INTL("{1}'s {2} had no effect on {3}!",
        opponent.pbThis,getAbilityName(opponent.ability),pbThis(true)))
      return false
    end
    if ((self.ability== :IMMUNITY) || (self.ability== :PASTELVEIL && @battle.FE != :INFERNAL))
      @battle.pbDisplay(_INTL("{1}'s {2} prevents {3}'s {4} from working!",
      pbThis,getAbilityName(self.ability),
      opponent.pbThis(true),getAbilityName(opponent.ability)))
      return false
    end
    if (pbPartner.ability== :PASTELVEIL && @battle.FE != :INFERNAL)
      abilityname=getAbilityName(pbPartner.ability)
      @battle.pbDisplay(_INTL("{1} stayed healthy using its partner's {2}!",pbThis,abilityname)) if showMessages
      return false
    end
    return true
  end

  def pbCanPoisonSpikes?(showMessages=false)
    return false if isFainted? && !(Rejuv && isbossmon && @shieldCount>0)
    return false if !pbCanStatus?(showMessages)
    return false if hasType?(:POISON) || hasType?(:STEEL) || (self.crested == :DHELMISE) # lawds - dhelmise crest acts like steel type
    return false if (self.ability== :IMMUNITY)
    return false if (self.ability== :PASTELVEIL && @battle.FE != :INFERNAL)

    if (pbPartner.ability== :PASTELVEIL && @battle.FE != :INFERNAL) && !(self.moldbroken)
      abilityname=getAbilityName(pbPartner.ability)
      @battle.pbDisplay(_INTL("{1} stayed healthy using its partner's {2}!",pbThis,abilityname)) if showMessages
      return false
    end
    return true
  end

  def pbPoison(attacker,toxic=false)
    self.status=:POISON
    if toxic
      self.statusCount=1
      self.effects[:Toxic]=0
    else
      self.statusCount=0
    end
    if self.index!=attacker.index
      @battle.synchronize[0]=self.index
      @battle.synchronize[1]=attacker.index
      @battle.synchronize[2]=:POISON
    end
    @battle.pbCommonAnimation("Poison",self,nil)
    if attacker.ability==:POISONPUPPETEER && pbCanConfuse?(true) # lawds poison puppeteer
      self.effects[:Confusion]=5
      @battle.pbCommonAnimation("Confusion",self,nil)
      @battle.pbDisplay(_INTL("{1}'s Poison Puppeteer confused {2}!",attacker.pbThis,self.pbThis))
      # LAWDS tangled feet
      if self.ability==:TANGLEDFEET
        if pbCanIncreaseStatStage?(PBStats::SPEED, false, nil, :TANGLEDFEET)
          pbIncreaseStatBasic(PBStats::SPEED,1,false,nil,false,:TANGLEDFEET)
          @battle.pbCommonAnimation("StatUp",self,nil)
          @battle.pbDisplay(_INTL("{1}'s Tangled Feet raised its Speed!",self.pbThis))
        end
      end
    end
  end

#===============================================================================
# Burn
#===============================================================================
  def pbCanBurn?(showMessages,ownFlameOrb=false)
    return false if isFainted? && !(Rejuv && isbossmon && @shieldCount>0)
    if self.status== :BURN
      @battle.pbDisplay(_INTL("{1} already has a burn.",pbThis)) if showMessages
      return false
    end
    return false if !pbCanStatus?(showMessages)
    if (self.ability== :WATERBUBBLE) && !(self.moldbroken)
      @battle.pbDisplay(_INTL("{1} is protected by its Water Bubble!",pbThis)) if showMessages
      return false
    end
    if hasType?(:FIRE)
      @battle.pbDisplay(_INTL("It doesn't affect {1}...",pbThis(true))) if showMessages
      return false
    end
    if (self.ability== :WATERVEIL) && !(self.moldbroken)
      @battle.pbDisplay(_INTL("{1}'s {2} prevents burns!",pbThis,getAbilityName(self.ability))) if showMessages
      return false
    end
    if self.ability== :THERMALEXCHANGE && !(self.moldbroken)   # LAWDS - Thermal Exchange
      @battle.pbDisplay(_INTL("{1} is protected by its Thermal Exchange!", pbThis)) if showMessages
      return false
    end
    return true
  end

  def pbCanBurnSynchronize?(opponent,showMessages=false)
    return false if isFainted? && !(Rejuv && isbossmon && @shieldCount>0)
    return false if !pbCanStatus?(showMessages)
    if (self.ability== :WATERBUBBLE) && !(self.moldbroken)
      @battle.pbDisplay(_INTL("{1} is protected by its Water Bubble!",pbThis)) if showMessages
      return false
    end
    if hasType?(:FIRE)
      @battle.pbDisplay(_INTL("{1}'s {2} had no effect on {3}!",
          opponent.pbThis,getAbilityName(opponent.ability),pbThis(true)))
      return false
    end
    if (self.ability== :WATERVEIL)
      @battle.pbDisplay(_INTL("{1}'s {2} prevents {3}'s {4} from working!",
      pbThis,getAbilityName(self.ability),
      opponent.pbThis(true),getAbilityName(opponent.ability)))
      return false
    end
    
    return true
  end

  def pbBurn(attacker)
    self.status=:BURN
    self.statusCount=0
    if self.index!=attacker.index
      @battle.synchronize[0]=self.index
      @battle.synchronize[1]=attacker.index
      @battle.synchronize[2]=:BURN
    end
    @battle.pbCommonAnimation("Burn",self,nil)
  end

#===============================================================================
# Paralyze
#===============================================================================
  def pbCanParalyze?(showMessages)
    return false if isFainted? && !(Rejuv && isbossmon && @shieldCount>0)
    if status== :PARALYSIS
      @battle.pbDisplay(_INTL("{1} is already paralyzed!",pbThis)) if showMessages
      return false
    end
    return false if !pbCanStatus?(showMessages)
    if hasType?(:ELECTRIC)
      @battle.pbDisplay(_INTL("But it failed!")) if showMessages
      return false
    end
    if (self.ability== :LIMBER) && !(self.moldbroken)
        @battle.pbDisplay(_INTL("{1}'s {2} prevents paralysis!",pbThis,getAbilityName(self.ability))) if showMessages
        return false
    end
    return true
  end

  def pbCanParalyzeSynchronize?(opponent,showMessages=false)
    return false if !pbCanStatus?(showMessages)
    if hasType?(:ELECTRIC)
      return false
    end
    if (self.ability== :LIMBER)
        @battle.pbDisplay(_INTL("{1}'s {2} prevents {3}'s {4} from working!",
        pbThis,getAbilityName(self.ability),
        opponent.pbThis(true),getAbilityName(opponent.ability)))
        return false
    end
    return true
  end

  def pbParalyze(attacker)
    self.status=:PARALYSIS
    self.statusCount=0
    if self.index!=attacker.index
      @battle.synchronize[0]=self.index
      @battle.synchronize[1]=attacker.index
      @battle.synchronize[2]=:PARALYSIS
    end
    @battle.pbCommonAnimation("Paralysis",self,nil)
  end

#===============================================================================
# Petrify
#===============================================================================
  def pbCanPetrify?(showMessages=true)
    return false if isFainted? && !(Rejuv && isbossmon && @shieldCount>0)
    if status== :PETRIFIED
      @battle.pbDisplay(_INTL("{1} is already petrified!",pbThis)) if showMessages
      return false
    end
    return false if !pbCanStatus?(showMessages)   
    if hasType?(:ROCK)
      @battle.pbDisplay(_INTL("But it failed!")) if showMessages
      return false
    end
    return true
  end

  def pbCanPetrifySynchronize?(opponent)
    return false            
  end

  def pbPetrify(attacker)
    self.status=:PETRIFIED
    if self.effects[:Substitute]<=0
      @battle.scene.pbUnSubstituteSprite(self,self.pbIsOpposing?(1))
    else
      @battle.scene.pbSubstituteSprite(self,self.pbIsOpposing?(1))
    end
    self.statusCount=0
    if self.index!=attacker.index
      @battle.synchronize[0]=self.index
      @battle.synchronize[1]=attacker.index
      @battle.synchronize[2]=:PETRIFIED
    end
  end


#===============================================================================
# Freeze
#===============================================================================
  def pbCanFreeze?(showMessages)
    return false # lawds no freeze
    return false if isFainted? && !(Rejuv && isbossmon && @shieldCount>0)
    return false if !pbCanStatus?(showMessages)
    return false if self.hasType?(:ICE)
    return false if @battle.pbWeather==:SUNNYDAY && !hasWorkingItem(:UTILITYUMBRELLA)
    return false if self.ability== :MAGMAARMOR && !(self.moldbroken) && @battle.FE != :FROZENDIMENSION
    return false if @battle.FE == :VOLCANIC    
    return true
  end

  def pbFreeze
    self.status=:FROZEN
    self.statusCount=0
    pbCancelMoves
    @battle.pbCommonAnimation("Frozen",self,nil)
  end

#===============================================================================
# Generalised status displays
#===============================================================================
  def pbContinueStatus(showAnim=true)
    case self.status
      when :SLEEP
        @battle.pbCommonAnimation("Sleep",self,nil)
        @battle.pbDisplay(_INTL("{1} is fast asleep.",pbThis))
      when :POISON
        @battle.pbCommonAnimation("Poison",self,nil)
        @battle.pbDisplay(_INTL("{1} is hurt by poison!",pbThis))
      when :BURN
        @battle.pbCommonAnimation("Burn",self,nil)
        @battle.pbDisplay(_INTL("{1} is hurt by its burn!",pbThis))
      when :PARALYSIS
        @battle.pbCommonAnimation("Paralysis",self,nil)
        @battle.pbDisplay(_INTL("{1} is paralyzed! It can't move!",pbThis))
      when :FROZEN
        @battle.pbCommonAnimation("Frozen",self,nil)
        @battle.pbDisplay(_INTL("{1} is frozen solid!",pbThis))
    end
    if self.isbossmon
      if self.chargeAttack
        if [:SLEEP,:PARALYSIS,:FROZEN].include?(self.status)
          self.chargeAttack[:turns]+=1
          self.chargeAttack[:canIntermediateAttack]=false 
        end
      end
    end
  end

  def pbCureStatus(showMessages=true)
    oldstatus=self.status
    if self.status== :SLEEP
      self.effects[:Nightmare]=false
    end
    self.status=nil
    self.statusCount=0
    self.shedskin=0 # lawds shed skin turn tracker
    if showMessages
      case oldstatus
        when :SLEEP
          @battle.pbDisplay(_INTL("{1} woke up!",pbThis))
          if self.isbossmon
            if self.chargeAttack
              self.chargeAttack[:canIntermediateAttack]=true
            end
          end
        when :POISON
        when :BURN
        when :PARALYSIS
        when :FROZEN
          @battle.pbDisplay(_INTL("{1} was defrosted!",pbThis))
          if self.isbossmon
            if self.chargeAttack
              self.chargeAttack[:canIntermediateAttack]=true
            end
          end
      end
    end
  end

#===============================================================================
# Confuse
#===============================================================================
  def pbCanConfuse?(showMessages=true)
    return false if isFainted? && !(Rejuv && isbossmon && @shieldCount>0)
    if damagestate.substitute || (@effects[:Substitute]>0 && (@battle.lastMoveUsed.is_a?(Symbol) && $cache.moves[@battle.lastMoveUsed].checkFlag?(:soundmove)))
      @battle.pbDisplay(_INTL("But it failed!")) if showMessages
      return false
    end
    if !pbCanConfuseSelf?(showMessages, true)
      return false
    end
    return true
  end

  def pbCanConfuseSelf?(showMessages, moldbreakercheck=false)
    return false if isFainted?
    if @effects[:Confusion]>0
      @battle.pbDisplay(_INTL("{1} is already confused!",pbThis)) if showMessages
      return false
    end
    if (self.ability== :OWNTEMPO) && !(self.moldbroken && moldbreakercheck)
      @battle.pbDisplay(_INTL("{1}'s {2} prevents confusion!",pbThis,getAbilityName(self.ability))) if showMessages
      return false
    end
    if @battle.FE == :ASHENBEACH && (hasType?(:FIGHTING) || (self.ability== :INNERFOCUS))
      @battle.pbDisplay(_INTL("{1} broke through the confusion!",pbThis)) if showMessages
      return false
    end
    if @battle.FE == :MISTY && !isAirborne? # Misty Field
      @battle.pbDisplay(_INTL("Misty Terrain prevents {1} from being inflicted by status!",pbThis(true))) if showMessages
      return false
    end
    return true
  end

  def pbConfuseSelf
    if @effects[:Confusion]==0 && !(self.ability== :OWNTEMPO)
      @effects[:Confusion]=2+@battle.pbRandom(4)
      @battle.pbCommonAnimation("Confusion",self,nil)
      @battle.pbDisplay(_INTL("{1} became confused!",pbThis))
      if self.ability==:TANGLEDFEET # LAWDS tangled feet
        if pbCanIncreaseStatStage?(PBStats::SPEED, false, nil, :TANGLEDFEET)
          pbIncreaseStatBasic(PBStats::SPEED,1,false,nil,false,:TANGLEDFEET)
          @battle.pbCommonAnimation("StatUp",self,nil)
          @battle.pbDisplay(_INTL("{1}'s Tangled Feet raised its Speed!",self.pbThis))
        end
      end
    end
  end

  def pbContinueConfusion
    @battle.pbCommonAnimation("Confusion",self,nil)
    @battle.pbDisplayBrief(_INTL("{1} is confused!",pbThis))
  end

  def pbCureConfusion(showMessages=true)
    @effects[:Confusion]=0
    @battle.pbDisplay(_INTL("{1} snapped out of confusion!",pbThis)) if showMessages
  end

  #===============================================================================
  # Attraction
  #===============================================================================
  def pbCanAttract?(attacker,showMessages=true)
    return false if isFainted? && !(Rejuv && isbossmon && @shieldCount>0)
    return false if !attacker
    if @effects[:Attract]>=0
      @battle.pbDisplay(_INTL("But it failed!")) if showMessages
      return false
    end
    agender=attacker.gender
    ogender=self.gender
    if agender==2 || ogender==2 || agender==ogender
      @battle.pbDisplay(_INTL("But it failed!")) if showMessages
      return false
    end
    if ability== (:OBLIVIOUS) && !(self.moldbroken) 
      @battle.pbDisplay(_INTL("{1}'s {2} prevents infatuation!",pbThis,
        getAbilityName(self.ability))) if showMessages
      return false
    end
    return true
  end

  def pbAnnounceAttract(seducer)
    @battle.pbCommonAnimation("Attract",self,nil)
    @battle.pbDisplayBrief(_INTL("{1} is in love with {2}!",
      pbThis,seducer.pbThis(true)))
  end

  def pbContinueAttract
    @battle.pbDisplay(_INTL("{1} is immobilized by love!",pbThis)) 
  end

  #===============================================================================
  # Increase stat stages
  #===============================================================================
  def pbTooHigh?(stat,movename=nil,abilname=nil,itemname=nil)
    return true if @stages[stat]>=6
    return true if stat==PBStats::EVASION && @stages[PBStats::EVASION]>=0 && $game_variables[:DifficultyModes]==2 # lawds - yeah.
    return false if !@battle.pbOwnedByPlayer?(@index) || ($game_variables[:DifficultyModes]!=2) || [PBStats::ACCURACY,PBStats::EVASION].include?(stat) || self.isbossmon # lawds
    value = 0 if stat == (PBStats::ATTACK)
    value = 1 if stat == (PBStats::DEFENSE)
    value = 2 if stat == (PBStats::SPATK)
    value = 3 if stat == (PBStats::SPDEF)
    value = 4 if stat == (PBStats::SPEED)

    return true if movename!=nil && (@stages[stat]>=(@effects[:StatBoosts][value][0]) && (@effects[:StatBoosts][value][1]).include?(movename))
    return true if abilname!=nil && (@stages[stat]>=(@effects[:StatBoosts][value][0]) && (@effects[:StatBoosts][value][2]).include?(abilname))
    return true if itemname!=nil && (@stages[stat]>=(@effects[:StatBoosts][value][0]) && (@effects[:StatBoosts][value][2]).include?(itemname))

    abilityCheck = !(self.ability.checkedAbility!=$checkedAbility || !(self.ability.equal?($checkedAbilObj)) || [:CONTRARY,:UNAWARE].include?($checkedAbility)) || abilname!=nil
    
    if itemname==nil && abilname==nil && movename==nil && $moveid!=nil && ($moveuser==self || [:SWAGGER,:FLOWERSHIELD,:COACHING,:FLATTER,:DECORATE,:SPICYEXTRACT,:HOWL,:MAGNETICFLUX,:ROTOTILLER,:GEARUP,:AROMATICMIST].include?($moveid))
      movename = $moveid
      movename = @effects[:EncoreMove] if @effects[:Encore] > 0
    elsif itemname==nil && movename==nil && abilname==nil && (self.ability.is_a?(PokeAbility)) && abilityCheck
      abilname = $checkedAbility #if self.ability==$checkedAbility
    end
    #@battle.pbDisplay("checking move") if movename!=nil
    #@battle.pbDisplay("checking abil") if abilname!=nil
    #@battle.pbDisplay("checking item") if itemname!=nil
    return true if movename!=nil && (@stages[stat]>=(@effects[:StatBoosts][value][0]) && (@effects[:StatBoosts][value][1]).include?(movename))
    return true if abilname!=nil && (@stages[stat]>=(@effects[:StatBoosts][value][0]) && (@effects[:StatBoosts][value][2]).include?(abilname))
    return true if itemname!=nil && (@stages[stat]>=(@effects[:StatBoosts][value][0]) && (@effects[:StatBoosts][value][2]).include?(itemname))
    return false
  end

  def pbCanIncreaseStatStage?(stat,showMessages=false,movename=nil,abilname=nil,itemname=nil)
    return false if isFainted? && !(Rejuv && isbossmon && @shieldCount>0)
    return false if stat==PBStats::EVASION && $game_variables[:DifficultyModes]==2 # lawds - yeah.
    if self.ability== :INDUSTRYSTANDARD # Lawds Mod - Industry Standard
      @battle.pbDisplay(_INTL("{1}'s Industry Standard prevents stat changes!", pbThis)) if showMessages
      return false
    end

    return true if @stages[stat]<6 && ($game_variables[:DifficultyModes]!=2 || self.isbossmon)


    if pbTooHigh?(stat,movename,abilname,itemname)
      @battle.pbDisplay(_INTL("{1}'s {2} won't go any higher!",pbThis,pbGetStatName(stat))) if showMessages
      return false
    end
    return true
  end

  def pbIncreaseStatBasic(stat,increment,itemcheck=false,itemid=nil,onactive=false,abilname=nil,movename=nil,mirrorable:true)
    if ((self.ability== :SIMPLE) && !(self.moldbroken))
      increment*=2
    end
    if !@battle.pbOwnedByPlayer?(self.index) || ($game_variables[:DifficultyModes]!=2) || [PBStats::ACCURACY,PBStats::EVASION].include?(stat) || self.isbossmon # lawds
      @stages[stat]+=increment
      @stages[stat]=6 if @stages[stat]>6
      @effects[:Jealousy] = true
      return
    end
    value = 0 if stat == (PBStats::ATTACK)
    value = 1 if stat == (PBStats::DEFENSE)
    value = 2 if stat == (PBStats::SPATK)
    value = 3 if stat == (PBStats::SPDEF)
    value = 4 if stat == (PBStats::SPEED)
    onactive = self.onactive if onactive==false # LAWDS for abilities that can boost on switch-in or in battle
    # LAWDS contrary boosts should be assigned to move boosts, unless it's not during move phase such as swamp speed drop
    abilityCheck = !(self.ability.checkedAbility!=$checkedAbility || !(self.ability.equal?($checkedAbilObj)) || [:CONTRARY,:UNAWARE].include?($checkedAbility)) || abilname!=nil
    abilname = $checkedAbility if movename==nil && abilityCheck && abilname==nil
    movename = $moveid if movename==nil
    movename = @effects[:EncoreMove] if @effects[:Encore] > 0 && movename!=nil
    initial = @stages[stat]
    if itemcheck==false && onactive==false && movename!=nil && abilname== nil && ($moveuser==self || [:SWAGGER,:FLOWERSHIELD,:COACHING,:FLATTER,:DECORATE,:SPICYEXTRACT,:HOWL,:MAGNETICFLUX,:ROTOTILLER,:GEARUP,:AROMATICMIST].include?(movename)) # move
      @effects[:StatBoosts][value][0]+=increment if !(@effects[:StatBoosts][value][1].include?(movename))
      @stages[stat]+=increment if (@stages[stat] < @effects[:StatBoosts][value][0])
      @effects[:StatBoosts][value][1].push(movename) if !(@effects[:StatBoosts][value][1].include?(movename))
      #@battle.pbDisplay("move")
    elsif itemcheck==false && onactive==true # switch-in
      @effects[:StatBoosts][value][0]+=increment
      @stages[stat]+=increment if (@stages[stat] < @effects[:StatBoosts][value][0])
      #@battle.pbDisplay("switch-in")
    elsif itemcheck==false && abilityCheck # ability
      @effects[:StatBoosts][value][0]+=increment if !(@effects[:StatBoosts][value][2].include?(abilname))
      @stages[stat]+=increment if (@stages[stat] < @effects[:StatBoosts][value][0])
      @effects[:StatBoosts][value][2].push(abilname) if !(@effects[:StatBoosts][value][2].include?(abilname))
      #@battle.pbDisplay("ability")
      #@battle.pbDisplay(_INTL("{1}",getAbilityName(abilname)))
    elsif itemcheck==true # item
      @effects[:StatBoosts][value][0]+=increment if !(@effects[:StatBoosts][value][2].include?(itemid))
      @stages[stat]+=increment if (@stages[stat] < @effects[:StatBoosts][value][0])
      @effects[:StatBoosts][value][2].push(itemid) if !(@effects[:StatBoosts][value][2].include?(itemid))
      #@battle.pbDisplay("item")
    end

    @stages[stat]=(@effects[:StatBoosts][value][0]) if @stages[stat]>(@effects[:StatBoosts][value][0])
    @stages[stat]=6 if @stages[stat]>6
    @effects[:Jealousy] = true
    stagesGained = @stages[stat] - initial
    @statsRaisedSinceLastCheck[stat] += stagesGained if mirrorable && stagesGained > 0
  end


  # changed from: def pbIncreaseStat(stat,increment,showMessages,attacker=nil,upanim=true)
  # lawds item tag, moveid tag this shit is a mess but i dont care
  def pbIncreaseStat(stat, increment, abilitymessage:true, statmessage:true, mirrorable:true,item:false,itemid:nil,moveid:nil)
    # Contrary handling
    if !@statrepeat && !(self.moldbroken) && (self.ability==:CONTRARY)
      @statrepeat = true
      cprint "Reducing stat with contrary\n"
      ret = pbReduceStat(stat,increment,abilitymessage:abilitymessage,statmessage:statmessage)
      @statrepeat = false
      return ret
    end
    canIncrease = item ? pbCanIncreaseStatStage?(stat,abilitymessage,nil,nil,itemid) : pbCanIncreaseStatStage?(stat,abilitymessage,moveid,nil)
    # Increase stat only if you can
    if canIncrease

      prestage = self.stages[stat]
      is_mirrorable = mirrorable
      pbIncreaseStatBasic(stat,increment,item,itemid,false,nil,moveid,mirrorable:is_mirrorable)
      poststage = self.stages[stat]
      # lawds i dont know why it even accesses this block. the conditional is the exact fucking same when decrementing the stage and checking if its at cap. but this gets rid of the display bullshit so ill put this here to catch it i guess. if it works then it works
      if prestage==poststage 
        @battle.pbDisplay(_INTL("{1}'s {2} won't go any higher!",pbThis,pbGetStatName(stat))) if abilitymessage
        @statrepeat=false
        return false
      end

      # Animation
      if !@statupanimplayed
        @battle.pbCommonAnimation("StatUp",self,nil)
        @statupanimplayed = true
      end
      
      # Battle message
      arrStatTexts=[_INTL("{1}'s {2} rose!",pbThis,pbGetStatName(stat)), _INTL("{1}'s {2} rose sharply!",pbThis,pbGetStatName(stat)),
         _INTL("{1}'s {2} rose drastically!",pbThis,pbGetStatName(stat)), _INTL("{1}'s {2} went way up!",pbThis,pbGetStatName(stat))]
      double_increment = ((self.ability== :SIMPLE) && !(self.moldbroken))
      increment*=2 if double_increment == true
      if increment>3
        @battle.pbDisplay(arrStatTexts[3]) if statmessage
      elsif increment==3
        @battle.pbDisplay(arrStatTexts[2]) if statmessage
      elsif increment==2
        @battle.pbDisplay(arrStatTexts[1]) if statmessage
      else
        @battle.pbDisplay(arrStatTexts[0]) if statmessage
      end
      @battle.reduceField if (stat == PBStats::EVASION) && @battle.ProgressiveFieldCheck(PBFields::CONCERT,2,4)
      @statrepeat = false
      return true
    end
    @statrepeat = false
    return false
  end

  #===============================================================================
  # Decrease stat stages
  #===============================================================================
  def pbTooLow?(stat,selfdrop=true) # lawds - added this for p3 synergies
    return true if self.ability==:INDUSTRYSTANDARD && !self.moldbroken
    # lawds magma armor
    return true if self.ability==:MAGMAARMOR && (@battle.pbWeather==:SUNNYDAY || [:VOLCANIC,:VOLCANICTOP,:DRAGONSDEN,:INFERNAL].include?(@battle.FE)) && @battle.FE!=:FROZENDIMENSION && !self.moldbroken
    return true if [:FULLMETALBODY,:CLEARBODY,:WHITESMOKE].include?(self.ability) && selfdrop=false && !self.moldbroken
    return true if self.hasWorkingItem(:CLEARAMULET) && selfdrop=false
    return true if [:BATTLEARMOR,:SHELLARMOR].include?(self.ability) && @battle.FE == :ROCKY && stat==PBStats::DEFENSE && !self.moldbroken # lawds - rocky battle/shell armor
    return @stages[stat]<=-1 if self.ability== :EXECUTION && (stat == PBStats::ATTACK || stat == PBStats::SPATK)
    return @stages[stat]<=-6
  end

  # Tickle (04A) and Memento (0E2) can't use this, but replicate it instead.
  # (Reason is they lower more than 1 stat independently, and therefore could
  # show certain messages twice which is undesirable.)
  def pbCanReduceStatStage?(stat,showMessages=false,selfreduce=false)
    return false if isFainted? && !(Rejuv && isbossmon && @shieldCount>0)
    if self.ability== :INDUSTRYSTANDARD # Lawds Mod 6/19/2024 - Industry Standard prevents all stat changes
      @battle.pbDisplay(_INTL("{1}'s Industry Standard prevents stat changes!", pbThis)) if showMessages
      return false
    end
    # lawds juggernaut
    return false if self.ability== :JUGGERNAUT && selfreduce
    # LAWDS rocky battle/shell armor
    if [:BATTLEARMOR,:SHELLARMOR].include?(self.ability) && stat==PBStats::DEFENSE && @battle.FE == :ROCKY && !self.moldbroken
      @battle.pbDisplay(_INTL("{1}'s solid armor protected its body amidst the rocks!",pbThis)) if showMessages
      return false
    end
    if !selfreduce
      if damagestate.substitute || @effects[:Substitute]>0 && (@battle.lastMoveUsed.is_a?(Symbol) && $cache.moves[@battle.lastMoveUsed].checkFlag?(:soundmove)) &&
        @battle.lastMoveUsed != :PLAYNICE
        @battle.pbDisplay(_INTL("But it failed!")) if showMessages
        return false
      end
      if pbOwnSide.effects[:Mist]>0 && (@battle.battlers[@battle.lastMoveUser]).ability != (:INFILTRATOR)
        @battle.pbDisplay(_INTL("{1} is protected by Mist!",pbThis)) if showMessages
        return false
      end
      # LAWDS - FMB no longer immune to mold breaker
      if (((self.ability== :CLEARBODY) || (self.ability== :WHITESMOKE) || (self.ability== :FULLMETALBODY)) && !(self.moldbroken))
        abilityname=getAbilityName(self.ability)
        @battle.pbDisplay(_INTL("{1}'s {2} prevents stat loss!",pbThis,abilityname)) if showMessages
        return false
      end
      if hasWorkingItem(:CLEARAMULET)
        @battle.pbDisplay(_INTL("{1}'s Clear Amulet prevents stat loss!",pbThis)) if showMessages
        return false
      end
      if stat==PBStats::ATTACK && (self.ability== :HYPERCUTTER) && !(self.moldbroken)
        abilityname=getAbilityName(self.ability)
        @battle.pbDisplay(_INTL("{1}'s {2} prevents Attack loss!",pbThis,abilityname)) if showMessages
        return false
      end
      if stat==PBStats::DEFENSE && (self.ability== :BIGPECKS) && !(self.moldbroken)
        abilityname=getAbilityName(self.ability)
        @battle.pbDisplay(_INTL("{1}'s {2} prevents Defense loss!",pbThis,abilityname)) if showMessages
        return false
      end
      if stat==PBStats::ACCURACY && !(self.moldbroken) && (self.ability== :KEENEYE)
        abilityname=getAbilityName(self.ability)
        @battle.pbDisplay(_INTL("{1}'s {2} prevents Accuracy loss!",pbThis,abilityname)) if showMessages
        return false
      end
      if (((ability== :FLOWERVEIL) || (pbPartner.ability== :FLOWERVEIL)) && (hasType?(:GRASS) || @battle.FE == :BEWITCHED)) && !(self.moldbroken)
        @battle.pbDisplay(_INTL("{1} is protected by Flower Veil!",pbThis)) if showMessages
        return false
      end
    end
    if pbTooLow?(stat)
      @battle.pbDisplay(_INTL("{1}'s {2} won't go any lower!",pbThis,pbGetStatName(stat))) if showMessages
      return false
    end
    return true
  end

  def pbReduceStatBasic(stat,increment,itemcheck=false,itemid=nil)
    if ((self.ability== :SIMPLE) && !(self.moldbroken))
      increment*=2 
    end
    @stages[stat]-=increment
    @stages[stat]=-6 if @stages[stat]<-6
    @statLowered = true
    @effects[:LashOut] = true
    # Lawds Mod - Spidops Crest
    for opp in [pbOppositeOpposing, pbOppositeOpposing.pbPartner]
      if opp.hp > 0 && opp.crested == :SPIDOPS && opp.pbCanIncreaseStatStage?(stat,false,nil,nil,opp.item)
        opp.pbIncreaseStatBasic(stat,increment)
      end
    end
  end

  def pbReduceStat(stat,increment,abilitymessage:true,statmessage:true, statdropper: nil, defiant_proc: true, mirrordrop: false)
    # here we play uno reverse if we have Mirror Armor
    if (self.ability== :MIRRORARMOR) && !mirrordrop && !(self.moldbroken) && (statdropper != self) && @battle.FE != :DARKCRYSTALCAVERN
      if !statdropper.nil?
        if statdropper.hp!=0
          @battle.pbDisplay(_INTL("{1}'s Mirror Armor reflected the stat drop!", pbThis))
          return statdropper.pbReduceStat(stat,increment,abilitymessage:abilitymessage,statmessage:statmessage,mirrordrop:true)
        end
      else
        mirrorOpp = self.pbOppositeOpposing
        if mirrorOpp.hp!=0
          @battle.pbDisplay(_INTL("{1}'s Mirror Armor reflected the stat drop!", pbThis))
          return mirrorOpp.pbReduceStat(stat,increment,abilitymessage:abilitymessage,statmessage:statmessage,mirrordrop:true)
        elsif mirrorOpp.pbPartner.hp!=0
          @battle.pbDisplay(_INTL("{1}'s Mirror Armor reflected the stat drop!", pbThis))
          return mirrorOpp.pbPartner.pbReduceStat(stat,increment,abilitymessage:abilitymessage,statmessage:statmessage,mirrordrop:true)
        end
      end
      @battle.pbDisplay(_INTL("{1}'s Mirror Armor blocked the stat drop!", pbThis))
      return false
    end

    # here we call increase if we have contrary
    # LAWDS - recoded this to work with setup cap
    if (self.ability==:CONTRARY) && !@statrepeat && !(self.moldbroken)
      if pbCanIncreaseStatStage?(stat,increment,false,nil,:CONTRARY)
        @statrepeat = true
        pbIncreaseStatBasic(stat,increment,false,nil,false,:CONTRARY)
        @statrepeat = false
        # Animation
        if !@statupanimplayed
          @battle.pbCommonAnimation("StatUp",self,nil)
          @statupanimplayed = true
        end
      
        # Battle message
        arrStatTexts=[_INTL("{1}'s {2} rose!",pbThis,pbGetStatName(stat)), _INTL("{1}'s {2} rose sharply!",pbThis,pbGetStatName(stat)),
          _INTL("{1}'s {2} rose drastically!",pbThis,pbGetStatName(stat)), _INTL("{1}'s {2} went way up!",pbThis,pbGetStatName(stat))]
        double_increment = ((self.ability== :SIMPLE) && !(self.moldbroken))
        increment*=2 if double_increment == true
        if increment>3
          @battle.pbDisplay(arrStatTexts[3]) if statmessage
        elsif increment==3
          @battle.pbDisplay(arrStatTexts[2]) if statmessage
        elsif increment==2
          @battle.pbDisplay(arrStatTexts[1]) if statmessage
        else
          @battle.pbDisplay(arrStatTexts[0]) if statmessage
        end
        @statrepeat = false
        return true
      else
        @statrepeat = false
        return false
      end
    end

    # Reduce only if you actually can
    if pbCanReduceStatStage?(stat,abilitymessage,statdropper==self)

      # Reduce animation
      if !@statdownanimplayed
        @battle.pbCommonAnimation("StatDown",self)
        @statdownanimplayed = true
      end

      # Battle message
      double_increment = ((self.ability== :SIMPLE) && !(self.moldbroken))
      increment*=2 if double_increment == true
      harsh = ""
      harsh = "harshly " if increment==2
      harsh = "dramatically " if increment>=3
      stat_text = _INTL("{1}'s {2} {3}fell!",pbThis,pbGetStatName(stat),harsh)
      @battle.pbDisplay(stat_text) if statmessage
      increment /=2 if double_increment == true
      pbReduceStatBasic(stat,increment)
      # Defiant/Competitive boost
      if defiant_proc
        if (self.ability== :DEFIANT) && pbCanIncreaseStatStage?(PBStats::ATTACK,false,nil,:DEFIANT) && (statdropper.nil? || self.pbIsOpposing?(statdropper.index))
          increment = 2
          increment = 3 if @battle.FE == :BACKALLEY
          pbIncreaseStatBasic(PBStats::ATTACK,increment,false,nil,false,:DEFIANT)
          @battle.pbCommonAnimation("StatUp",self,nil)
          if @battle.FE == :BACKALLEY
            @battle.pbDisplay(_INTL("Defiant dramatically raised {1}'s Attack!", pbThis(true)))
          else
            @battle.pbDisplay(_INTL("Defiant sharply raised {1}'s Attack!", pbThis(true)))
          end
        end
        if (self.ability== :COMPETITIVE && !(Rejuv && @battle.FE == :CHESS)) && pbCanIncreaseStatStage?(PBStats::SPATK,false,nil,:COMPETITIVE) && (statdropper.nil? || self.pbIsOpposing?(statdropper.index))
          increment = 2
          increment = 3 if @battle.FE == :CITY
          pbIncreaseStatBasic(PBStats::SPATK,increment,false,nil,false,:COMPETITIVE)
          @battle.pbCommonAnimation("StatUp",self,nil)
          if @battle.FE == :CITY
            @battle.pbDisplay(_INTL("Competitive dramatically raised {1}'s Special Attack!", pbThis(true)))
          else
            @battle.pbDisplay(_INTL("Competitive sharply raised {1}'s Special Attack!", pbThis(true)))
          end
        end
      end
      @battle.reduceField if (stat == PBStats::EVASION || stat == PBStats::ACCURACY) && @battle.ProgressiveFieldCheck(PBFields::CONCERT,2,4)
      @statrepeat = false
      return true
    end
    @statrepeat = false
    return false
  end

  def pbReduceAttackStatStageIntimidate(opponent)
    # Ways intimidate doesn't work
    return false if isFainted? && !(Rejuv && isbossmon && @shieldCount>0)
    return false if @effects[:Substitute]>0
    if (self.ability== :CLEARBODY) || (self.ability== :WHITESMOKE) || (self.ability== :HYPERCUTTER) || (self.ability== :FULLMETALBODY) || 
      (self.ability== :INNERFOCUS) || (self.ability== :OBLIVIOUS) || (self.ability== :OWNTEMPO) || (self.ability== :SCRAPPY)
      abilityname=getAbilityName(self.ability)
      oppabilityname=getAbilityName(opponent.ability)
      @battle.pbDisplay(_INTL("{1}'s {2} prevented {3}'s {4} from working!", pbThis,abilityname,opponent.pbThis(true),oppabilityname))
      if hasWorkingItem(:ADRENALINEORB) && pbCanIncreaseStatStage?(PBStats::SPEED,false,nil,nil,:ADRENALINEORB) && self.stages[PBStats::ATTACK] > -6
        triggerAdrenalineOrb
      end
      return false
    end
    if pbOwnSide.effects[:Mist]>0 && (@battle.battlers[@battle.lastMoveUser]).ability != (:INFILTRATOR)
      @battle.pbDisplay(_INTL("{1} is protected by Mist!",pbThis))
      if hasWorkingItem(:ADRENALINEORB) && pbCanIncreaseStatStage?(PBStats::SPEED,false,nil,nil,:ADRENALINEORB) && self.stages[PBStats::ATTACK] > -6
        triggerAdrenalineOrb
      end
      return false
    end
    # Gen 9 Mod - Clear Amulet prevents stat drop from intimidate
    if hasWorkingItem(:CLEARAMULET)
      itemname = getItemName(self.item)
      oppabilityname = getAbilityName(opponent.ability)
      @battle.pbDisplay(_INTL("{1}'s {2} prevented {3}'s {4} from working!", pbThis, itemname, opponent.pbThis(true), oppabilityname))
      return false
    end
    # Gen 9 Mod - Guard Dog raises attack on Intimidate
    if (self.ability== :GUARDDOG)
      @battle.pbDisplay(_INTL("{1} got angry!",pbThis))
      pbIncreaseStat(PBStats::ATTACK, 1)
      if hasWorkingItem(:ADRENALINEORB) && pbCanIncreaseStatStage?(PBStats::SPEED, false) && self.stages[PBStats::ATTACK] > -6
        triggerAdrenalineOrb
      end
      return false
    end

    # reduce stat only if you can
    if @battle.FE == :CROWD && pbCanReduceStatStage?(PBStats::DEFENSE,false)
      pbReduceStat(PBStats::DEFENSE,1,statmessage:false, statdropper: opponent, defiant_proc: false)
      oppabilityname=getAbilityName(opponent.ability)
      @battle.pbDisplay(_INTL("{1}'s {2} cuts {3}'s Defense!",opponent.pbThis, oppabilityname,pbThis(true))) if !(self.ability== :CONTRARY)
      @battle.pbDisplay(_INTL("{1}'s {2} boosts {3}'s Defense!",opponent.pbThis, oppabilityname,pbThis(true))) if (self.ability== :CONTRARY)
      # Defiant/Competitive
      if (self.ability== :DEFIANT)
        increment = 2
        increment = 3 if @battle.FE == :BACKALLEY
        pbIncreaseStat(PBStats::ATTACK,increment,statmessage:false)
        if @battle.FE == :BACKALLEY
          @battle.pbDisplay(_INTL("Defiant dramatically raised {1}'s Attack!", pbThis(true)))
        else
          @battle.pbDisplay(_INTL("Defiant sharply raised {1}'s Attack!", pbThis(true)))
        end
      end
      if (self.ability== :COMPETITIVE && !(Rejuv && @battle.FE == :CHESS))
        increment = 2
        increment = 3 if @battle.FE == :CITY
        pbIncreaseStat(PBStats::SPATK,increment,statmessage:false)
        if @battle.FE == :CITY
          @battle.pbDisplay(_INTL("Competitive dramatically raised {1}'s Special Attack!",pbThis(true)))
        else
          @battle.pbDisplay(_INTL("Competitive sharply raised {1}'s Special Attack!", pbThis(true)))
        end
      end
    end
    if pbCanReduceStatStage?(PBStats::ATTACK,false)
      pbReduceStat(PBStats::ATTACK,1,statmessage:false, statdropper: opponent, defiant_proc: false)
      # Battle message
      oppabilityname=getAbilityName(opponent.ability)
      @battle.pbDisplay(_INTL("{1}'s {2} cuts {3}'s Attack!",opponent.pbThis, oppabilityname,pbThis(true))) if !(self.ability== :CONTRARY)
      @battle.pbDisplay(_INTL("{1}'s {2} boosts {3}'s Attack!",opponent.pbThis, oppabilityname,pbThis(true))) if (self.ability== :CONTRARY)

      if (self.ability== :RATTLED)
        pbIncreaseStat(PBStats::SPEED,1,statmessage:false)
        @battle.pbDisplay(_INTL("{1}'s Rattled raised its Speed!", pbThis))
      end

      # Defiant/Competitive
      if (self.ability== :DEFIANT)
        increment = 2
        increment = 3 if @battle.FE == :BACKALLEY
        pbIncreaseStat(PBStats::ATTACK,increment,statmessage:false)
        if @battle.FE == :BACKALLEY
          @battle.pbDisplay(_INTL("Defiant dramatically raised {1}'s Attack!", pbThis(true)))
        else
          @battle.pbDisplay(_INTL("Defiant sharply raised {1}'s Attack!", pbThis(true)))
        end
      end
      if (self.ability== :COMPETITIVE && !(Rejuv && @battle.FE == :CHESS))
        increment = 2
        increment = 3 if @battle.FE == :CITY
        pbIncreaseStat(PBStats::SPATK,increment,statmessage:false)
        if @battle.FE == :CITY
          @battle.pbDisplay(_INTL("Competitive dramatically raised {1}'s Special Attack!",pbThis(true)))
        else
          @battle.pbDisplay(_INTL("Competitive sharply raised {1}'s Special Attack!", pbThis(true)))
        end
      end

      # Item triggers
      if hasWorkingItem(:ADRENALINEORB) && pbCanIncreaseStatStage?(PBStats::SPEED,false)
        triggerAdrenalineOrb
      end
      if hasWorkingItem(:WHITEHERB)
        reducedstats=false
        for i in 1..7
        if self.stages[i]<0
          self.stages[i]=0; reducedstats=true
          end
        end
        if reducedstats
          itemname=(self.item.nil?) ? "" : getItemName(self.item)
          @battle.pbDisplay(_INTL("{1}'s {2} restored its status!",pbThis,itemname))
          pbDisposeItem(false)
        end
      end

      return true
    end
    return false
  end

  def triggerAdrenalineOrb
    pbIncreaseStat(PBStats::SPEED,1,statmessage:false,item: true, itemid: :ADRENALINEORB)
    @battle.pbDisplay(_INTL("{1}'s Adrenaline Orb raised its Speed!",pbThis(true)))
    pbDisposeItem(false)
  end

# Gen 9 Mod - Supersweet Syrup implementation
def pbReduceEvasionStatStageSyrup(opponent)
  # Can only trigger once per battle
  #return false if opponent.supersweetSyrupTriggered # lawds supersweet syrup no longer triggers only once
  # Regadless if it is effective or not, it is only used once, but on both enemies on double battles.
  if @battle.doublebattle && !opponent.pbOpposing1.isFainted? && !opponent.pbOpposing2.isFainted?
    if opponent.supersweetSyrupTriggeredDoubleBattle == true
      opponent.supersweetSyrupTriggered = true
    else
      opponent.supersweetSyrupTriggeredDoubleBattle = true
    end
  else
    opponent.supersweetSyrupTriggered = true
  end
  # Ways Supersweet Syrup doesn't work
  return false if isFainted? && !(Rejuv && isbossmon && @shieldCount > 0)
  return false if @effects[:Substitute] > 0
  if [:CLEARBODY, :WHITESMOKE, :FULLMETALBODY].include?(self.ability)
    abilityname = getAbilityName(self.ability)
    oppabilityname=getAbilityName(opponent.ability)
    @battle.pbDisplay(_INTL("{1}'s {2} prevented {3}'s {4} from working!", pbThis, abilityname, opponent.pbThis(true), oppabilityname))
    return false
  end
  # Gen 9 Mod - Clear Amulet prevents stat drop
  if hasWorkingItem(:CLEARAMULET)
    itemname=getItemName(self.item)
    oppabilityname=getAbilityName(opponent.ability)
    @battle.pbDisplay(_INTL("{1}'s {2} prevented {3}'s {4} from working!", pbThis, itemname, opponent.pbThis(true), oppabilityname))
    return false
  end
  if pbOwnSide.effects[:Mist] > 0
    @battle.pbDisplay(_INTL("{1} is protected by Mist!",pbThis))
    return false
  end
  # reduce stat only if you can
  if pbReduceStat(PBStats::EVASION, 1, statmessage:false, statdropper: opponent, defiant_proc: false)
    # Battle message
    oppabilityname = getAbilityName(opponent.ability)
    @battle.pbDisplay(_INTL("A supersweet aroma is wafting from the syrup covering {1}! Evasion drops!", opponent.pbThis(true))) if !(self.ability== :CONTRARY)
    @battle.pbDisplay(_INTL("A supersweet aroma is wafting from the syrup covering {1}! Evasion increases!", opponent.pbThis(true))) if (self.ability== :CONTRARY)

    # Defiant/Competitive
    if (self.ability== :DEFIANT)
      increment = 2
      increment = 3 if @battle.FE == :BACKALLEY
      pbIncreaseStat(PBStats::ATTACK, increment, statmessage:false)
      if @battle.FE == :BACKALLEY
        @battle.pbDisplay(_INTL("Defiant dramatically raised {1}'s Attack!", pbThis(true)))
      else
        @battle.pbDisplay(_INTL("Defiant sharply raised {1}'s Attack!", pbThis(true)))
      end
    end
    if (self.ability== :COMPETITIVE && !(Rejuv && @battle.FE == :CHESS))
      increment = 2
      increment = 3 if @battle.FE == :CITY
      pbIncreaseStat(PBStats::SPATK, increment, statmessage: false)
      if @battle.FE == :CITY
        @battle.pbDisplay(_INTL("Competitive dramatically raised {1}'s Special Attack!", pbThis(true)))
      else
        @battle.pbDisplay(_INTL("Competitive sharply raised {1}'s Special Attack!", pbThis(true)))
      end
    end

    # Item triggers
    if hasWorkingItem(:WHITEHERB)
      reducedstats = false
      for i in 1..7
      if self.stages[i] < 0
        self.stages[i] = 0; reducedstats = true
        end
      end
      if reducedstats
        itemname = (self.item.nil?) ? "" : getItemName(self.item)
        @battle.pbDisplay(_INTL("{1}'s {2} restored its status!", pbThis, itemname))
        pbDisposeItem(false)
      end
    end

    return true
  end
  return false
end


  def pbReduceIlluminate(opponent)
    # Ways illuminate doesn't work
    return false if isFainted? && !(Rejuv && isbossmon && @shieldCount>0)
    return false if @effects[:Substitute]>0
    if (self.ability== :CLEARBODY) || (self.ability== :WHITESMOKE) ||
      (self.ability== :FULLMETALBODY) || (self.ability== :KEENEYE)
      abilityname=getAbilityName(self.ability)
      oppabilityname=getAbilityName(opponent.ability)
      @battle.pbDisplay(_INTL("{1}'s {2} prevented {3}'s {4} from working!",
        pbThis,abilityname,opponent.pbThis(true),oppabilityname))
      return false
    end
    if pbOwnSide.effects[:Mist]>0 && (@battle.battlers[@battle.lastMoveUser]).ability != (:INFILTRATOR)
      @battle.pbDisplay(_INTL("{1} is protected by Mist!",pbThis))
      return false
    end

    # reduce stat only if you can
    if pbCanReduceStatStage?(PBStats::ACCURACY,false)
      pbReduceStat(PBStats::ACCURACY,1,statmessage:false)
      oppabilityname=getAbilityName(opponent.ability)
      @battle.pbDisplay(_INTL("{1}'s {2} cuts {3}'s Accuracy!",opponent.pbThis,
        oppabilityname,pbThis(true)))
      return true
    end
    return false
  end

  def pbGetStatName(stat)
    #can't use STATSTRINGS for this bc that doesn't have Acc and Eva 
    return ["HP","Attack", "Defense", "Sp. Attack", "Sp. Defense", "Speed", "Accuracy", "Evasion"][stat]
  end

    # Gen 9 Mod - Method to check for Opportunist and Mirror Herb triggers
  def opportunistCheck
    return if isFainted?
    return if self.ability != :OPPORTUNIST && !hasWorkingItem(:MIRRORHERB)
    for i in @battle.battlers
      next if i.isFainted? || !pbIsOpposing?(i.index)
      hash = i.statsRaisedSinceLastCheck
      if self.ability== :OPPORTUNIST && hash.keys.any? {|stat| hash[stat]>0 && pbCanIncreaseStatStage?(stat)}
        @battle.pbDisplay(_INTL("{1} seized the opportunity to boost its own stats!",pbThis))
        for stat in hash.keys
          pbIncreaseStat(stat,hash[stat], abilitymessage:false, mirrorable:false)
        end
      end
      if hasWorkingItem(:MIRRORHERB) && hash.keys.any? {|stat| hash[stat]>0 && pbCanIncreaseStatStage?(stat,false,nil,nil,:MIRRORHERB)}
        @battle.pbDisplay(_INTL("{1} used its {2} to mirror its opponent's stat boosts!",pbThis,getItemName(self.item)))
        for stat in hash.keys
          pbIncreaseStat(stat,hash[stat],abilitymessage:false, mirrorable:false)
        end
        pbDisposeItem(false)
      end
    end
  end
end
