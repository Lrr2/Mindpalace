module DifficultModes
  # Variable number that control the difficult.
  # To use a different variable, change this. 0 deactivates this script
  VARIABLE=200 
  
  def self.currentMode
    difficultHash={}
    
    
    easyMode = Difficult.new
    
    # partyid (six parameter) number for trainer than can have other party.
    # Trainers loaded this way ignores the levelProcedure.
    # IN THIS EXAMPLE: If you start a battle versus YOUNGSTER Ben team 1,
    # the game searches for the YOUNGSTER Ben team 101 (100+1),
    # if the game founds it loads instead of the team 1.
    easyMode.idJump = 0
    
    # A formula to change all trainers pokémon level. 
    # This affects money earned in battle.
    # IN THIS EXAMPLE: Every opponent pokémon that aren't found by idJump value
    # have the level*0.8 (round down). A pokémon level 6 will be level 4.
    easyMode.levelProcedure = proc{|level|
      next level*0.9
    }
    
    # A formula to change all trainers pokémon money.
    # This is the last formula to apply.
    # IN THIS EXAMPLE: Multiplier the money given by the opponent by 1.3 (round
    # down), so if the final money earned is 99, the money will be 128.
    easyMode.moneyProcedure = proc{|money|
      next money*0
    }
    # You can delete any of these three attributes if you didn't want them.
    
    # The Hash index is the value than when are in the VARIABLE number value,
    # the difficult will be ON.
    # IN THIS EXAMPLE: Only when variable 90 value is 1 than this changes
    # will occurs 
    difficultHash[1] = easyMode
    
    
    hardMode = Difficult.new
    hardMode.idJump = 0
    hardMode.levelProcedure = proc{|level|
      next level
    }
    hardMode.moneyProcedure = proc{|money|
      next money*0
    }
    difficultHash[2] = hardMode
    # lawds AM and lite mode use the same teams and shit
    return difficultHash[2] if $game_variables[:Difficulty_Modes]==0
    return DifficultModes::VARIABLE>0 ? 
      difficultHash[pbGet(DifficultModes::VARIABLE)] : nil
  end 
  
  def self.applyLevelProcedure(level,procedure)
    return level # lawds forget level procedures
    #return procedure ? [[procedure.call(level).floor,MAXIMUMLEVEL].min,1].max : level
  end
  
  def self.applyMoneyProcedure(money)
    difficultSelected = self.currentMode
    return difficultSelected && difficultSelected.moneyProcedure ? [difficultSelected.moneyProcedure.call(money).floor,0].max : money
  end
  # LAWDS playerteam parameter for non-pc sections
  def self.loadTrainer(trainerid,trainername,partyid=0,noscaling=false,playerteam=false)
    trainer = nil
    procedure = nil
    difficultSelected = self.currentMode
    #difficultSelected = nil if noscaling && $game_variables[:DifficultyModes]!=2 # lawds force scaling to apply so it loads the correct teams for players
    if difficultSelected
      trainer=pbLoadTrainerDifficult(trainerid,trainername,partyid + difficultSelected.idJump,playerteam: playerteam)
      procedure = difficultSelected.levelProcedure
    end
    return trainer ? trainer : pbLoadTrainerDifficult(trainerid,trainername,partyid,procedure,playerteam: playerteam)
  end
    
  private
  class Difficult
    attr_accessor :idJump
    attr_accessor :levelProcedure
    attr_accessor :moneyProcedure
    
    def initialize
      @idJump = 0
      @levelProcedure = nil
      @moneyProcedure = nil
    end  
  end  
end

def pbLoadTrainer(trainerid,trainername,partyid=0,noscaling=false,playerteam=false) # LAWDS - check if the trainer being loaded will belong to the player during character switch, i.e. sections where you play as someone else. allows trainers loaded during these sections to still have empty EVs
  return DifficultModes.loadTrainer(trainerid,trainername,partyid,noscaling,playerteam)
end

def bossFunction(boss,bossid,pokemon)
  pokemon.enablebossmon 
  pokemon.shieldCount = boss.shieldCount
  pokemon.bossId = bossid
end

def pbLoadTrainerDifficult(type,name,id=0,procedure=nil,playerteam: false) # LAWDS - check if the trainer being loaded will belong to the player during character switch, i.e. sections where you play as someone else. allows trainers loaded during these sections to still have empty EVs
  trainer = findParty(type,name,id)
  puts "Team could not be loaded, please report this: #{type}, #{name}, #{id} \n ty <3" if !trainer
  return nil if !trainer
  items=trainer[2]
  opponent=PokeBattle_Trainer.new(name,type)
  opponent.name = $game_variables[:KieranName].capitalize if type == :UNKNOWN_1 && name == "???" && $game_variables[:KieranName] != 0
  opponent.setForeignID($Trainer,$cache.trainertypes[type].trainerID) if $Trainer
  opponent.aceline = trainer[3]
  opponent.defeatline = trainer[4] ? trainer[4] : ""

  if opponent.defeatline == "" && $game_variables[:DifficultyModes] > 0 && id>=100
    case $game_variables[:DifficultyModes]
    when 1
      id-=100
    when 2
      id-=200
    end
    trainermode = findParty(type,name,id)
    opponent.defeatline = trainermode[4] ? trainermode[4] : ""
  end
  if opponent.aceline == "" && $game_variables[:DifficultyModes] > 0 && id>=100
    case $game_variables[:DifficultyModes]
    when 1
      id-=100
    when 2
      id-=200
    end
    trainermode = findParty(type,name,id)
    opponent.aceline = trainermode[3] ? trainermode[3] : ""
  end
  opponent.trainereffect = trainer[5]
  bossdata = $cache.bosses
  party = []
  for poke in trainer[1]
    pokeIndex = trainer[1].index(poke)
    boss = poke[:boss] ? bossdata[poke[:boss]] : nil
    bossid = poke[:boss]
    poke = boss.moninfo if boss 
    species = poke[:species]
    level = DifficultModes.applyLevelProcedure(poke[:level],procedure)
    form = poke[:form]? poke[:form]:0
    pokemon = PokeBattle_Pokemon.new(species,level,opponent,false,form) 
     # lawds
    pokemon.zoro_illusion_detected = false
    statMults = poke[:statMults] ? poke[:statMults] : [1,1,1,1,1,1]
    if $game_variables[:DifficultyModes] < 2 || ($game_switches[:Empty_IVs_And_EVs_Password])
      for i in 0...6
        statMults[i]=1 if statMults[i]>1
      end
    end
    pokemon.setInnates(statMults)
    bossFunction(boss,bossid,pokemon) if boss
    pokemon.setItem(poke[:item])
    pokemon.form = pokemon.getForm(pokemon)
    pokemon.crestUsed = false
    if poke[:moves]
      k=0
      for move in poke[:moves]
        next if move.nil?
        pokemon.moves[k]=PBMove.new(move)
        if level >=59 && opponent.skill>=PokeBattle_AI::BESTSKILL && $game_variables[:DifficultyModes]==2
          pokemon.moves[k].ppup=3
          pokemon.moves[k].pp=pokemon.moves[k].totalpp
        end
	      pokemon.moves[k].pp = 1 if move==:TRUMPCARD && $game_switches[342]
        k+=1
      end
    else
      pokemon.resetMoves
    end
    pokemon.initZmoves(pokemon.item,false) if $cache.items[pokemon.item] && $cache.items[pokemon.item].checkFlag?(:zcrystal)
    pokemon.setAbility(poke.fetch(:ability,pokemon.getAbilityList[0]))
    case poke[:gender]
      when "M" then pokemon.setGender(0)
      when "F" then pokemon.setGender(1)
      when "N" then pokemon.setGender(2)
      else
        pokemon.setGender(rand(2))
    end
    pokemon.shinyflag = poke[:shiny] || false
    pokemon.presetPiece = poke[:piece] # lawds custom piece assignment
    pokemon.setNature(poke.fetch(:nature,:HARDY))
    iv=poke.fetch(:iv,10)
    if iv==32 # Trick room IVS
      pokemon.iv=Array.new(6,31)
      pokemon.iv[5]=0
    else
      iv = 31 #if ($game_switches[:Only_Pulse_2] && !(poke[:shadow])) || (poke[:shadow] &&  $game_switches[:Full_IVs])  # pulse 2 mode    # LAWDS - enemies have 31IV by default
    end
    iv = 0 if $game_switches[:Empty_IVs_And_EVs_Password] && !playerteam # lawds - let player's team keep IVs
    pokemon.iv=Array.new(6,iv)
    evs = poke[:ev]
    if $game_variables[:DifficultyModes]!=2 || !evs # LAWDS auto assignment of EVs on lite mode and story mode, and on AM if EVs are not assigned
      if $game_variables[:DifficultyModes]==1
        evs = Array.new(6,0)
      else
        evs = Array.new(6,[85,level*3/2].min)
      end
    end
    if playerteam==false
      lawdsfunny = $game_variables[814]==9 && $game_variables[646] < 68 && $game_variables[:DifficultyModes]==2 && [:TRAINER_AEVIS,:TRAINER_AEVIA,:TRAINER_ARIA,:TRAINER_AXEL,:TRAINER_ALAIN,:TRAINER_AERO,:TRAINER_ANA].include?(type)
      if ($game_switches[:Only_Pulse_2] || lawdsfunny) && !(poke[:shadow]) # pulse 2 mode
        for i in 0...6 # LAWDS if a boss pokemon like ch11 pidove has > 252 EVs in a stat, dont override them.
          evs[i] = 252 if evs[i] < 252
        end
      end
      evs = Array.new(6,85) if $game_switches[:Flat_EV_Password]
      evs = Array.new(6,0) if $game_switches[:Empty_IVs_And_EVs_Password]
    end

    pokemon.ev = evs.clone
    pokemon.ev[PBStats::SPEED] = 0 if iv==32 #TR team, just to make sure!

    pokemon.happiness=poke.fetch(:happiness,70)
    pokemon.name=poke[:name] if poke[:name]
    
    # lawds - not letting shadow mons be p3. cassandra kingambit is the exception
    nop3 = poke[:pulse3]!=nil && poke[:pulse3]==false
    nop3 = true if !poke[:moves] || !poke[:ev]
    if (poke[:shadow]!=true || poke[:species]==:KINGAMBIT) && (!nop3) && $game_variables[:DifficultyModes]==2 # lawds - pulse3, awesome mode
#      pokemon.enablePULSE3
    else
      pokemon.PULSE3=false
    end
    if poke[:seeded] && $game_variables[:DifficultyModes]==2 # LAWDS preseed, only on awesome mode
      pokemon.seeded = true
    else
      pokemon.seeded = false
    end

    # LAWDS pre status
    if poke[:status]!=nil && [:BURN,:POISON,:PARALYSIS,:SLEEP,:FREEZE,:PETRIFIED].include?(poke[:status]) && $game_variables[:DifficultyModes]==2
      pokemon.status = poke[:status]
      pokemon.statusCount=2 if [:SLEEP,:FREEZE].include?(poke[:status])
    end

    if poke[:shadow]   # if this is a Shadow Pokémon
      pokemon.makeShadow rescue nil
      pokemon.pbUpdateShadowMoves(true) rescue nil
      pokemon.makeNotShiny
    end
    pokemon.obtainText = poke[:catchtext] if poke[:catchtext]
    pokemon.obtainMode = poke[:obtaintype] if poke[:obtaintype]
    pokemon.obtainLevel = poke[:catchlevel] if poke[:catchlevel]
    pokemon.obtainMap = poke[:catchmap] if poke[:catchmap]
    #timediverge = $Settings.unrealTimeDiverge
    #$Settings.unrealTimeDiverge = 0
    #timeNow = pbGetTimeNow
    #pokemon.timeReceived= Time.unrealTime_oldTimeNew(timeNow.year+poke[:catchtime][0],poke[:catchtime][1],poke[:catchtime][2],timeNow.hour,timeNow.min,timeNow.sec) if poke[:catchtime]
    #pokemon.hatchedMap = poke[:hatchmap] if poke[:hatchmap]
    #pokemon.timeEggHatched= Time.unrealTime_oldTimeNew(timeNow.year+poke[:hatchtime][0],poke[:hatchtime][1],poke[:hatchtime][2],timeNow.hour,timeNow.min,timeNow.sec) if poke[:hatchtime]
    #$Settings.unrealTimeDiverge = timediverge
    pokemon.ot = poke[:originalTrainer] if poke[:originalTrainer]
    pokemon.trainerID = poke[:trainerID] if poke[:trainerID]
    pokemon.personalID = pokemon.personalID.to_s if poke[:hiddenID]
    pokemon.ballused=poke.fetch(:ball,:POKEBALL)
    pokemon.calcStats
    pokemon.hp = pokemon.totalhp
    party.push(pokemon)
  end
  return [opponent,items,party]
end