# Secret Mod: Win Speed Ties
# Replaces random speed tie ordering with player-owned mon always going first

class PokeBattle_Battle
  alias __old_pbPriority pbPriority
  
  def pbPriority(ignorequickclaw = true,megacalc = false)
    return @priority if @usepriority && !megacalc # use stored priority if round isn't over yet (best ged rid of this in gen 8)
    @priority.clear
    priorityarray = []
    quickclawarray = [0,0,0,0]
    # -Move priority take precedence(stored as priorityarray[i][0])
    # -Then Items  (stored as priorityarray[i][1])
    # -Then speed (stored as priorityarray[i][2]) (trick room is applied by just making speed negative.)
    # -The last element is just the battler index (which is otherwise lost when sorting)
    for i in 0..3
      priorityarray[i] = [0,0,0,i] #initializes the array and stores the battler index

      # Move priority
      pri = 0
      if (@choices[i][0] == 2 || @battle.switchedOut[i]) # If switching or has switched
        pri = 12
      end
      if @choices[i][0] == 3 #Used item
        pri = 11
      end
      if @choices[i][0] == 1 # Is a move
        pri = @choices[i][2].priority  #Base move priority
        pri -= 1 if @battle.FE == :DEEPEARTH && @choices[i][2].move == :COREENFORCER
	      # lawds gravity
	      pri = 0 if @choices[i][2].move == :GRAVITY && @field.effect==:DEEPEARTH
        pri = 0 if PBStuff::POWDERMOVES.include?(@choices[i][2].move) && @battlers[i].ability==:MYCELIUMMGHT # lawds mycelium might
        pri += 1 if @field.effect == :CHESS && @battlers[i].pokemon && @battlers[i].pokemon.piece == :KING
        pri += 1 if @battlers[i].ability==:PRANKSTER && @choices[i][2].basedamage==0 && @battlers[i].effects[:TwoTurnAttack] == 0 # Is status move
        pri += 1 if @battlers[i].crested == :MRRIME && [:LIGHTSCREEN, :REFLECT, :AURORAVEIL, :ARENITEWALL].include?(@choices[i][2].move) # LAWDS Mod 6/19/2024 - Mr. Rime Crest grants priority to screen moves
        # LAWDS - Gale Wings doesn't work on specific fields. also updated to use pbType rather than @type
        pri += 1 if @battlers[i].ability==:GALEWINGS && (@choices[i][2].pbType(@battlers[i])==:FLYING) && ((@battlers[i].hp == @battlers[i].totalhp) || ((@field.effect == :MOUNTAIN || @field.effect == :SNOWYMOUNTAIN || @field.effect == :VOLCANICTOP) && @weather == :STRONGWINDS)) && ![:UNDERWATER, :DEEPEARTH, :CAVE].include?(@field.effect)
        pri += 1 if @choices[i][2].move == :GRASSYGLIDE && (@field.effect == :GRASSY || @state.effects[:GRASSY] > 0 || (@battlers[i].crested==:GOGOAT) || @battlers[i].pbPartner.crested==:GOGOAT)
        pri += 1 if @choices[i][2].move == :QUASH && @field.effect == :DIMENSIONAL
        pri += 1 if @choices[i][2].basedamage != 0 && @battlers[i].crested == :FERALIGATR && @battlers[i].turncount == 1 # Feraligatr Crest
        pri += 3 if @battlers[i].ability==:TRIAGE && (PBStuff::HEALFUNCTIONS).include?(@choices[i][2].function)
        pri = -11 if @field.effect==:COLOSSEUM && [0x0E8,0x0EC, 0x13D, 0x903, 0x0ED, 0x0EE, 0x120].include?(@choices[i][2].function) # lawds colosseum
      end
      priorityarray[i][0]=pri
      #Item/stall priority (all items overwrite stall priority)
      #priorityarray[i][1] = -1 if @battlers[i].ability==:STALL 
      # lawds new quick draw
      if !ignorequickclaw && @choices[i][0] == 1 # Is a move
        if @battlers[i].custap
          priorityarray[i][1] = 1
          quickclawarray[i] = :CUSTAPBERRY
        end
      end
      priorityarray[i][1] = -2 if (@battlers[i].itemWorks? && (@battlers[i].item == :LAGGINGTAIL || @battlers[i].item == :FULLINCENSE))

      #speed priority
      priorityarray[i][2] = @battlers[i].pbSpeed if @trickroom == 0
      priorityarray[i][2] = -@battlers[i].pbSpeed if @trickroom > 0
      
    end
    priorityarray.sort!

    #Speed ties. Only works correctly if two pokemon speed tie
    speedtie = []
    # print("before:")
    # print(priorityarray)
    for i in 0..2
      for j in (i + 1)..3
        if priorityarray[i][0] == priorityarray[j][0] && priorityarray[i][1] == priorityarray[j][1] && priorityarray[i][2] == priorityarray[j][2]
          if pbOwnedByPlayer?(priorityarray[i][3])
            priorityarray[i], priorityarray[j] = priorityarray[j], priorityarray[i]
            # print("here")
          end
        end
      end
    end
    priorityarray.reverse!

    # print("after:")
    # print(priorityarray)

    # Quick claw battle message
    # lawds removing messages due to quick claw & quick draw rework
    for i in 0..3
      @priority[i] = @battlers[priorityarray[i][3]]
    end
    x = []
    # print(@priority[0])

    @usepriority=true
    return @priority
  end
end